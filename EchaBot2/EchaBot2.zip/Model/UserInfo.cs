﻿namespace EchaBot2.Model
{
    public class UserInfo
    {
        public string Email { get; set; }
    }
}
